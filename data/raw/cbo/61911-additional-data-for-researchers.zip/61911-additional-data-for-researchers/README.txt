# The Distribution of Household Income, 2022--Additional Data for Researchers

The data contained here supplement information provided in the Congressional Budget 
Office's January 2026 report _The Distribution of Household Income, 2022_,
www.cbo.gov/publication/61911

## Contents
There are 37 files in this zipped archive file--a README.txt file (this file) 
and three sets of 12 files in comma-separated values (.csv) format.

Each set uses a different income measure to rank households and construct income groups:
    * inc_after_trans_tax (income after transfers and taxes) 
    * inc_before_trans_tax (income before transfers and taxes)
    * market_inc (market income)

The csv files are in a directory labeled CBO_distribution_household_income_2022_data:
    
    * households_ranked_by_inc_after_trans_tax_table_01_demographics_1979_2022.csv
    * households_ranked_by_inc_after_trans_tax_table_02_income_group_minimums_1979_2022.csv
    * households_ranked_by_inc_after_trans_tax_table_03_average_household_income_1979_2022.csv
    * households_ranked_by_inc_after_trans_tax_table_04_median_household_income_1979_2022.csv
    * households_ranked_by_inc_after_trans_tax_table_05_components_ibtt_1979_2022.csv
    * households_ranked_by_inc_after_trans_tax_table_06_components_means_tested_transfers_1979_2022.csv
    * households_ranked_by_inc_after_trans_tax_table_07_components_federal_taxes_1979_2022.csv
    * households_ranked_by_inc_after_trans_tax_table_08_means_tested_transfer_rates_1979_2022.csv
    * households_ranked_by_inc_after_trans_tax_table_09_federal_tax_rates_1979_2022.csv
    * households_ranked_by_inc_after_trans_tax_table_10_household_income_shares_1979_2022.csv
    * households_ranked_by_inc_after_trans_tax_table_11_means_tested_transfer_shares_1979_2022.csv
    * households_ranked_by_inc_after_trans_tax_table_12_federal_tax_shares_1979_2022.csv
    
    * households_ranked_by_inc_before_trans_tax_table_01_demographics_1979_2022.csv
    * households_ranked_by_inc_before_trans_tax_table_02_income_group_minimums_1979_2022.csv
    * households_ranked_by_inc_before_trans_tax_table_03_average_household_income_1979_2022.csv
    * households_ranked_by_inc_before_trans_tax_table_04_median_household_income_1979_2022.csv
    * households_ranked_by_inc_before_trans_tax_table_05_components_ibtt_1979_2022.csv
    * households_ranked_by_inc_before_trans_tax_table_06_components_means_tested_transfers_1979_2022.csv
    * households_ranked_by_inc_before_trans_tax_table_07_components_federal_taxes_1979_2022.csv
    * households_ranked_by_inc_before_trans_tax_table_08_means_tested_transfer_rates_1979_2022.csv
    * households_ranked_by_inc_before_trans_tax_table_09_federal_tax_rates_1979_2022.csv
    * households_ranked_by_inc_before_trans_tax_table_10_household_income_shares_1979_2022.csv
    * households_ranked_by_inc_before_trans_tax_table_11_means_tested_transfer_shares_1979_2022.csv
    * households_ranked_by_inc_before_trans_tax_table_12_federal_tax_shares_1979_2022.csv
    
    * households_ranked_by_market_inc_table_01_demographics_1979_2022.csv
    * households_ranked_by_market_inc_table_02_income_group_minimums_1979_2022.csv
    * households_ranked_by_market_inc_table_03_average_household_income_1979_2022.csv
    * households_ranked_by_market_inc_table_04_median_household_income_1979_2022.csv
    * households_ranked_by_market_inc_table_05_components_ibtt_1979_2022.csv
    * households_ranked_by_market_inc_table_06_components_means_tested_transfers_1979_2022.csv
    * households_ranked_by_market_inc_table_07_components_federal_taxes_1979_2022.csv
    * households_ranked_by_market_inc_table_08_means_tested_transfer_rates_1979_2022.csv
    * households_ranked_by_market_inc_table_09_federal_tax_rates_1979_2022.csv
    * households_ranked_by_market_inc_table_10_household_income_shares_1979_2022.csv
    * households_ranked_by_market_inc_table_11_means_tested_transfer_shares_1979_2022.csv
    * households_ranked_by_market_inc_table_12_federal_tax_shares_1979_2022.csv

The files with households ranked by inc_before_trans_tax contain the same data
that are available in the file "61911-supplemental-data.xlsx."

To open the files without read-only access, save the zipped archive to a
local file directory and extract the files to a new directory.

## General Notes
All data files are in comma-separated values format.
Column headings are in row 1; data start in row 2.

All years in the data are calendar years.

Households with negative income are not shown separately but are included in 
the all_quintiles income_group.

### Rounding
Numbers in the data may not add up to totals because of rounding. Dollar values are rounded to the nearest hundred, and dollar values between -$50 and $50 are entered as zero. Percentages are rounded to the nearest tenth, and percentage values between -0.05 percent and 0.05 percent are entered as zero. Finally, population counts of less than 0.05 million are entered as zero.

### File Structure
Most files are sorted by three variables: household_type, income_group, and
year. 

There are four household_type values:
    * all_households
    * hh_with_children (a household with one or more people under age 18)
    * elderly_headed_hh (a household with either a head or spouse age 65 or older)
    * nonelderly_childless_hh (may have secondary elderly persons living in the
      household but no children)

Note that for data broken out by household type, the income groups are defined on
the basis of the full population, not within each household type.

Only six files are **not** sorted by those variables:

    * households_ranked_by_inc_after_trans_table_02_income_group_minimums_1979_2022.csv
    * households_ranked_by_inc_after_trans_table_04_median_household_income_1979_2022.csv
    
    * households_ranked_by_inc_before_trans_table_02_income_group_minimums_1979_2022.csv
    * households_ranked_by_inc_before_trans_table_04_median_household_income_1979_2022.csv
    
    * households_ranked_by_market_inc_table_02_income_group_minimums_1979_2022.csv
    * households_ranked_by_market_inc_table_04_median_household_income_1979_2022.csv

For the income_group_minimums tables, the values are for the income measure used
to rank households.

For the median_household_income tables, the data are identical across the three
files and represent the median income values for all_households. (The data are
duplicated solely for file-naming consistency across the household rankings.)

### Income Measures
All income measures are average 2022 dollars.

To remove the effects of inflation, CBO adjusted income with the price index for personal consumption expenditures from the Bureau of Economic Analysis. That index is updated regularly. To adjust the data in this file, CBO used the revision of the series published on July 9, 2024. 

**Income groups** are created by ranking households by their size-adjusted income per the income measure specified. A household consists of people sharing a housing unit, regardless of their relationships. Each income quintile (fifth) contains approximately equal numbers of people but slightly different numbers of households. Similarly, each full percentile (hundredth) contains approximately equal numbers of people but different numbers of households. If a household has negative income (that is, if its business or investment losses exceed its other income), it is excluded from the lowest income group but included in totals.

**Income before transfers and taxes** consists of market income plus social
insurance benefits.

**Market income** comprises wages and other forms of labor income (including cash wages, employers' contributions for health insurance premiums, and payroll taxes paid by employers), business income, capital income (including capital gains), and other income.

**Social insurance benefits** consist of Social Security and Medicare benefits, regular unemployment insurance (but not the expanded unemployment compensation provided during the COVID-19 pandemic), and workers' compensation.

**Means-tested transfers** are cash payments and in-kind services provided through federal, state, and local government assistance programs, such as Medicaid and the Children's Health Insurance Program (CHIP), the Supplemental Nutrition Assistance Program (SNAP, formerly known as the Food Stamp Program), and Supplemental Security Income (SSI). Eligibility to receive such transfers is determined primarily on the basis of income, which must be below certain thresholds. The largest transfer programs are Medicaid and CHIP (values shown here are the average cost to the government of providing those benefits to a given income group), SNAP, and SSI.

**Federal taxes** consist of individual income taxes, payroll taxes, corporate income taxes, and excise taxes. Receipts from those four sources accounted for 90 percent of federal revenues in fiscal year 2022. The remaining federal revenue sources, which are not allocated to U.S. households in the data presented here, include states' deposits for unemployment insurance, estate and gift taxes, net income earned by the Federal Reserve, customs duties, and miscellaneous fees and fines. In this data file, taxes for a given year are the amount a household owes on the basis of income received that year, regardless of when the taxes are paid.

**Average means-tested transfer rates** are calculated by dividing total means-tested transfers for a given income group by that group's total income before transfers and taxes.

**Average federal tax rates** are calculated by dividing total federal taxes for a given income group by that group's total income before transfers and taxes.

### Rate Measures
All rate measures use inc_before_trans_tax as the denominator, regardless of 
the income measure used to rank households.

All rates are income-weighted averages. For example, the average federal tax 
rate for any given income group is equal to the sum of all federal taxes paid
by households in the income group divided by all income before transfers and
taxes in the income group.

### Share Measures 
Shares do not add up to 100 percent because households with negative income are 
not shown.

Shares are calculated separately for each household type.
